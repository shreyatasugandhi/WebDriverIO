describe('Working with Elements', function(){

    it('Working with select box and redio buttons', async () => {

        await browser.url('http://zero.webappsecurity.com/login.html')    

        await $('#user_login').setValue('username')
        await $('#user_password').setValue('password')
        await $('[name="submit"]').click()

        await browser.navigateTo('http://zero.webappsecurity.com/bank/pay-bills.html')
        await browser.pause(3000)
        await $('=Purchase Foreign Currency').click()


        // working with radio buttons
        const redioButton = await $('#pc_inDollars_true')
        redioButton.click()

        if(!(await redioButton.isSelected())){
            await redioButton.click()       
        }
        await browser.pause(3000)

        // working with select box
        const selectBox = await $('#pc_currency')

        // select by visible text
        await selectBox.selectByVisibleText('Denmark (krone)')
        
        await expect(selectBox).toHaveValue('Denmark (krone')

        await browser.pause(3000)

        //select by value attribute
        await selectBox.selectByAttribute('value', 'GBP')

        await browser.pause(3000)

        //select by index
        await selectBox.selectByIndex(4)


        await browser.pause(3000)

        
    })

    

})