import fs from 'fs'


describe('File Upload Test', () => {
    it('Should upload a file successfully', async () => {

        await browser.url('https://the-internet.herokuapp.com/upload')
        
        // Define the local file path to be uploaded (Ensure this path is correct on your system. Ensure you add an absolute path.)
        const filePath = 'C:/Users/Lenovo/OneDrive/Desktop/Sample.txt'

        // Upload the file to the WebDriver session and get the remote file path
        const remoteFilePath = await browser.uploadFile(filePath)

        // Set the uploaded file path in the input field
        await $('#file-upload').setValue(remoteFilePath)

        // Click the submit button to upload the file
        await $('#file-submit').click()

        // Validate that the uploaded file name appears on the page
        await expect($('#uploaded-files')).toHaveText(expect.stringContaining('Sample.txt'))

    })




    it.only('Should download a file successfully', async () => {
        await browser.url('https://the-internet.herokuapp.com/download')

        // Define file name (Adjust based on available files)
        const fileName = 'some-file.txt'
        
        // Click the download link
        const fileLink = await $(`a=${fileName}`)
        await fileLink.click()

        // Wait for the file to be downloaded (Adjust timeout if needed)
        await browser.pause(5000) 

        // Define the default download directory (adjust based on OS)
        const filePath = 'C:/Users/Lenovo/Downloads/some-file.txt' // this is my default path of chrome browser 
        console.log(`File downloaded successfully to: ${filePath}`)

        
    })

})
