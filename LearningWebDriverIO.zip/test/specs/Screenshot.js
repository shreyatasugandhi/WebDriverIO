describe('Screenshot Test', function () {

    it('should take a screenshot of the homepage', async function () {
        await browser.url('https://the-internet.herokuapp.com/')

        // Verify the page title
        await expect(browser).toHaveTitle('The Internet')

        // Take a screenshot
        // browser.saveScreenshot(filename)
        await browser.saveScreenshot('homepage.png')
        
        console.log('Screenshot saved as homepage.png')
    })
})
