import { browser, expect } from '@wdio/globals'

describe('Google Autosuggestion Test', () => {
    it('Should select an autosuggestion from Google search', async () => {
        await browser.url('https://www.google.com')

        const searchBox = await $('[name="q"]')
        await searchBox.setValue('WebdriverIO')

        // Wait for autosuggestions to appear
        const suggestionList = await $$('ul[role="listbox"] li')
        await browser.waitUntil(async () => suggestionList.length > 0, {
            timeout: 5000,
            timeoutMsg: 'Autosuggestions did not appear',
        })

        // Select a suggestion, for example, the first one
        const firstSuggestion = await suggestionList[0]
        const suggestionText = await firstSuggestion.getText()
        
        // // Validate that search box contains the selected suggestion
        // await expect('put the expect suggestion value from your site').toHaveValue(suggestionText)

        console.log(`Selected suggestion: ${suggestionText}`)
        
    })
})
