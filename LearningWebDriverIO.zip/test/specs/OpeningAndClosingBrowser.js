const { remote } = require('webdriverio');

describe('WebdriverIO Browser Test', function () {
    let browser;

    before(async function () {
        browser = await remote({
            capabilities: {
                browserName: 'firefox', // Use 'firefox', 'edge', etc., as needed
            }
        });
    });

    it('should open and close the browser', async function () {
        await browser.url('https://www.google.com'); // Open a website
        await browser.pause(2000); // Pause to observe (optional)
    });

    after(async function () {
        await browser.deleteSession(); // Close the browser session
    });
});
