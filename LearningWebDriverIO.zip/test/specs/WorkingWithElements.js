describe('Handling Elements', function () {

    it('Working with elements', async () => {

        browser.url('http://zero.webappsecurity.com/')

        // maximize the window
        await browser.maximizeWindow()

        // Text field operations 


        // add value & set value
        // add value will not delete existing text but it will just uppend the text to the existing value
        // set value will clear the text field and set new value into it

        const searchTextBox = await $('#searchTerm')
        await searchTextBox.setValue('online')
        await browser.pause(3000)   

        await searchTextBox.addValue(' banking')
        await browser.pause(3000)   

        await searchTextBox.setValue('Transfer Funds')
        await browser.pause(3000)   

        // get current value from the text feild 
        const currentText = await searchTextBox.getValue()
        console.log("Current value in the search box is - ", currentText)

        // clear the text field
        await searchTextBox.clearValue()



        // // working with buttons

        const buttonSignin = await $('#signin_button')

        // await buttonSignin.click()

        // is button clickable         
        const isButtonClickable = await buttonSignin.isClickable()
        console.log('Is button clickable? --- ', isButtonClickable)


        // is button enabled or not?
        const isButtonEnabled = await buttonSignin.isEnabled()
        console.log('Is button enabled? --- ', isButtonEnabled)


        // is button displayed or visibal?
        const isButtonDisplayed = await buttonSignin.isDisplayed()
        console.log('Is button displayed? --- ', isButtonDisplayed)

        // check if element exists on the web page
        const buttonExists = await buttonSignin.isExisting()
        console.log('Does the Sign In button exists on the page? ', buttonExists)

        // check focus is on the specific element
        const buttonFocused = await buttonSignin.isFocused()
        console.log('Does signin button have focus? - ', buttonFocused)


        //getting the property/attributes of the elements
        await $('#online-banking').click()
        const link = await $('=Online Statements')
        const linkId = await link.getAttribute('id')

        console.log('Id of the given link text is = ', linkId)


        // getting atrribute of a text field
        console.log('The placehold attribute value for search text box is -- ', await searchTextBox.getAttribute('placeholder'))

        
        // gettting css property of the element
        const cssProp_Link =  await link.getCSSProperty('font-size')
        console.log('The font size of the link is - ', cssProp_Link)
        

        // navigte to url
        await browser.navigateTo("http://zero.webappsecurity.com/login.html")


        // Working with Checkbox
        // isSelected -- selected == checked

        const checkBox = await $('#user_remember_me')
        await browser.pause(3000)

        if(!(await checkBox.isSelected())){
            await checkBox.click()   
            await expect(checkBox).toBeSelected()
            await expect(checkBox).toBeChecked()    
        }

        await browser.pause(3000)



    })

})
