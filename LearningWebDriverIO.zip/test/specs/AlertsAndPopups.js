describe('WebdriverIO Alerts & Popups Handling', () => {

    it('should handle a simple alert', async () => {
        await browser.url('http://the-internet.herokuapp.com/javascript_alerts')

        // Click the button to trigger an alert
        const alertButton = await $('button=Click for JS Alert')
        await alertButton.click()

        // get text from the alert
        const alertText = await browser.getAlertText()
        console.log('Text on the Alert - ', alertText)

        // Accept the alert
        await browser.acceptAlert()

        // Verify the result text
        const resultText = await $('#result')
        await expect(resultText).toHaveText(expect.stringContaining('You successfully clicked an alert'))
        
    })


    it('should handle a confirmation alert (accept and dismiss)', async () => {
        await browser.url('http://the-internet.herokuapp.com/javascript_alerts')

        // Click the button to trigger a confirmation alert
        const confirmButton = await $('button=Click for JS Confirm')
        await confirmButton.click()

         // get text from the alert
         const confirmText = await browser.getAlertText()
         console.log('Text on the confirmation - ', confirmText)

         // validation for text on confirmation Popup
         expect(confirmText).toEqual('I am a JS Confirm')

        // Accept the alert
        await browser.acceptAlert()
        await expect($('#result')).toHaveText('You clicked: Ok')

        // Trigger the confirmation alert again
        await confirmButton.click()

        // Dismiss the alert
        await browser.dismissAlert()
        await expect($('#result')).toHaveText('You clicked: Cancel')
    })


    it.only('should handle a prompt alert', async () => {
        await browser.url('http://the-internet.herokuapp.com/javascript_alerts')

        // Click the button to trigger a prompt alert
        const promptButton = await $('button=Click for JS Prompt')
        await promptButton.click()

        // Enter text into the prompt alert
        const inputText = 'WebdriverIO Test'
        await browser.sendAlertText(inputText)
        await browser.acceptAlert()

        // Verify the entered text is displayed
        await expect($('#result')).toHaveText('You entered: ' + inputText)
    })


})
