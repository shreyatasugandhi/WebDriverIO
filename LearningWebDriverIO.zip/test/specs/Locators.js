describe('Locators Techniques', function(){

    it('Learning Locators', async () => {

        browser.url('http://zero.webappsecurity.com/login.html')
        // // by id
        // await $('#user_login').setValue('username')
        
        // //by name
        // await $('[name="user_password"]').setValue('password')

        // // by tagName
        // await $('.icon-question-sign').click()

        // // console.log(await $('h3').getText())  // to fetch or get the text from app

        // let headerText = await $('h3').getText()
        // console.log(headerText)

        // //by link text
        // await $('=Forgot your password ?').click()

        // // by partial link text
        // await $('*=Forgot').click()


        // // CSS selector in combination format
        // await $('input#user_login').setValue('username')
        // await $('input[name="user_password"]').setValue('password')
        // await $('i.icon-question-sign#credentials').click()
        // // await $('input[type="submit"]').click()
        // await $('a[href="/forgot-password.html"]').click()


        // Xpath 
        await $('//label[contains(text(), \'Login\')]').click()

        // await $('//input[@id="user_login"]').setValue('username')
        // await $("//input[@id='user_login']").setValue('username')

        await $("//*[@type='password']").setValue('password')

        await $('//input[contains(@type, "checkbox")]').click()

        await browser.pause(3000)



    })



})