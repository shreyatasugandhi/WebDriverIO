describe('Demo Test Set', function(){

    it('LogInScript', async () => {

        browser.url('https://www.google.com/')    // to open url in current browser
        await $('[name="q"]').setValue("webdriverio") 
        // $ - single element
        // $$ - multiple elements

        // await browser.keys('Enter')    // Keyboard action

        await $('[name="btnK"]').click()

        
    })

})