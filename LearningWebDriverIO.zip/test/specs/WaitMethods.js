
/*
Types of waits in 
*/
describe('WebdriverIO Wait Methods Example', () => {

    it('should demonstrate implicit wait', async () => {
        //implicit wait
        await browser.setTimeout({ implicit: 7000 }) // Set global implicit wait (7 sec)
    
        await browser.url('https://the-internet.herokuapp.com/dynamic_loading/1')
    
        const startButton = await $('button')
        await startButton.click()
    
        const finishText = await $('#finish') // WebdriverIO will wait up to 7 sec
        console.log(await finishText.getText()) // Might fail if element is not visible
    })
  

    it('should wait until an element is displayed', async () => {
        await browser.url('https://the-internet.herokuapp.com/dynamic_loading/1')

        const startButton = await $('button') // "Start" button
        await startButton.click()

        const finishText = await $('#finish') // Element to appear after loading

        // Wait for the element to be displayed
        await finishText.waitForDisplayed({ timeout: 7000 })

        // Verify text appears
        const text = await finishText.getText()
        console.log('Loaded Text:', text)
        await expect(text).toContain('Hello World!')


    })


    it('should wait until an element exists', async () => {
        await browser.url('https://the-internet.herokuapp.com/dynamic_controls')

        const removeButton = await $('button[onclick="swapCheckbox()"]')
        const checkbox = await $('#checkbox')

        await removeButton.click()

        // Wait until the checkbox is removed from the DOM
        await checkbox.waitForExist({ timeout: 5000, reverse: true })

        console.log('Checkbox removed successfully.')
    })



    it('should wait until an element is enabled', async () => {
        await browser.url('https://the-internet.herokuapp.com/dynamic_controls')

        const enableButton = await $('button[onclick="swapInput()"]')
        const inputField = await $('#input-example input')

        await enableButton.click()

        // Wait for the input field to be enabled
        await inputField.waitForEnabled({ timeout: 5000 })

        await inputField.setValue('WebdriverIO is awesome!')

        await browser.pause(2000)

    })


    it('should wait until an element is clickable', async () => {
        await browser.url('https://the-internet.herokuapp.com/add_remove_elements/')

        const addButton = await $('button[onclick="addElement()"]')
        const deleteButton = await $('button.added-manually')
        
        await addButton.click()

        // Wait for the delete button to be clickable
        await deleteButton.waitForClickable({ timeout: 5000 })

        await deleteButton.click()
        console.log('Element deleted successfully.')

        await browser.pause(2000)
    })




    it('should use browser.waitUntil() for custom conditions', async () => {
        await browser.url('https://the-internet.herokuapp.com/dynamic_loading/2')
    
        const startButton = await $('button')
        await startButton.click()
    
        const finishText = await $('#finish')
    
        // Wait until text is displayed
        await browser.waitUntil(
            async () => {
                return await finishText.isDisplayed()
            },
            {
                timeout: 7000,
                timeoutMsg: 'Expected text to be displayed but it was not'
            }
        )
    
        console.log('Text is now visible:', await finishText.getText())

    })
    
   it('should demonstrate fluent wait using waitUntil()', async () => {
        await browser.url('https://the-internet.herokuapp.com/dynamic_loading/2')
    
        const startButton = await $('button')
        await startButton.click()
    
        const finishText = await $('#finish')
    
        // Fluent wait: Wait until the text is displayed
        await browser.waitUntil(
            async () => {
                return await finishText.isDisplayed()
            },
            {
                timeout: 10000, // Wait up to 10 seconds
                interval: 500, // Check every 500ms
                timeoutMsg: 'Text did not appear within 10 seconds'
            }
        )
    
        console.log('Text is now visible:', await finishText.getText())
    })
    

})
