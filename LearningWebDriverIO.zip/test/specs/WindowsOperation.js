describe('Wondows operation', function(){

    it('Working with window operations', async () => {

        browser.url('http://zero.webappsecurity.com/')

        // maximize the window
        await browser.maximizeWindow()

        await browser.pause(3000)
        

        // // getting current url from the browser
        // console.log(await browser.getUrl())

        const url = await browser.getUrl()
        console.log(url)
        

        // navigte to url
        await browser.navigateTo("http://zero.webappsecurity.com/login.html")

        await browser.pause(3000)
        
        // back operation on window
        await browser.back()
        await browser.pause(3000)
        
        // forward opration on window
        await browser.forward()
        await browser.pause(3000)
        
        // refresh operation on window
        await browser.refresh()
        await browser.pause(3000)
        
        //get title
        console.log("The title of the page is  -  ", await browser.getTitle())


        // how to create a new tab
        // browser.createWindow(type)
        await browser.createWindow('tab')
        await browser.pause(3000)

        
        // minimize the window
        await browser.minimizeWindow()
        await browser.pause(3000)
        
        

        // Full screen
        await browser.fullscreenWindow()
        await browser.pause(3000)
        

        
        // close window
        await browser.closeWindow()
        await browser.pause(3000)

        
        await browser.pause(3000)
        


        
    })

})