describe('WebdriverIO Actions Test Suite', function () {
    
    it('Performs drag and drop action', async function () {
        await browser.url('https://the-internet.herokuapp.com/drag_and_drop')

        const sourceElement = await $('#column-a')
        const targetElement = await $('#column-b')
        await browser.pause(2000) // Wait for elements to be available

        // Get initial text before drag and drop
        const initialSourceText = await sourceElement.getText()
        const initialTargetText = await targetElement.getText()

        // Perform Drag and Drop
        await browser.action('pointer')
            .move({ origin: sourceElement })
            .down()
            .move({ origin: targetElement })
            .up()
            .perform()

        await browser.pause(2000)

        // Validate text has changed after drag and drop
        await expect(sourceElement).not.toHaveText(initialSourceText)
        await expect(targetElement).not.toHaveText(initialTargetText)
    })



    it('should perform right-click on context menu', async () => {
        await browser.url('https://swisnl.github.io/jQuery-contextMenu/demo.html')
        // maximize the window
        await browser.maximizeWindow()

        const rightClickBox = await $('span.context-menu-one') // Element to right-click

        // Right-click (context menu action)
        await browser.action('pointer')
            .move({ origin: rightClickBox })
            .down({ button: 2 }) // Right-click
            .up({ button: 2 })
            .perform()

        // Verify context menu is displayed
        const contextMenu = await $('.context-menu-list')
        await expect(contextMenu).toBeDisplayed()
    })




    it('should hover over an element and verify tooltip', async () => {
        await browser.url('http://the-internet.herokuapp.com/hovers')

        const avatar = await $$('div.figure img') // Select all avatars
        const firstAvatar = avatar[0] // Select first avatar

        // Hover over the first avatar
        await browser.action('pointer')
            .move({ origin: firstAvatar })
            .perform()

        // Fix selector to properly locate the tooltip text
        const tooltip = await firstAvatar.parentElement().$('h5') // Locate h5 within the parent container
        await expect(tooltip).toBeDisplayed()

    })



    it('Performs scroll actions and validates visibility', async function () {
        await browser.url('https://the-internet.herokuapp.com/large')

        const scrollTarget = await $('//h3[contains(text(), "Large & Deep DOM")]')
        await browser.pause(2000) // Wait for element

        // Scroll to the element
        await scrollTarget.scrollIntoView()
        await browser.pause(2000)

        // Validate element is in viewport
        await expect(scrollTarget).toBeDisplayedInViewport()

        // Scroll down by pixels
        await browser.execute(() => window.scrollBy(0, 500))
        await browser.pause(2000)

        // Scroll up by pixels
        await browser.execute(() => window.scrollBy(0, -500))
        await browser.pause(2000)
    })

    
    it.only('Performs keyboard actions and validates input', async function () {
        await browser.url('https://the-internet.herokuapp.com/key_presses')

        const inputField = await $('#target')
        const resultField = await $('#result')
        await browser.pause(2000) // Wait for elements

        // Click input field
        await inputField.click()
        await browser.pause(1000)

        // Type text
        await browser.keys('WebdriverIO Test')
        await browser.pause(2000)

        // Validate typed text
        await expect(inputField).toHaveValue('WebdriverIO Test')        
        
        // Press Enter key once will refresh the page
        await browser.keys(['Enter'])
        
        //Press enter key for validation
        await browser.keys(['Enter'])
        await browser.pause(3000)

        // Validate key press result
        await expect(resultField).toHaveText(expect.stringContaining('ENTER'))
        
        
         // Use Shift + A (uppercase A)
         await browser.keys(['Shift', 'A'])
         await browser.pause(2000)
 
         // Validate Shift + A
         await expect(resultField).toHaveText(expect.stringContaining('A'))

         
        // Use Tab key
        await browser.keys(['Tab'])
        await browser.pause(1000)

        // Validate Shift tab
        await expect(resultField).toHaveText(expect.stringContaining('TAB'))

        // // Ensure input field has longer focuse
        // const isFocused = await inputField.isFocused()
        // expect(isFocused).toBe(false)

    })

})
