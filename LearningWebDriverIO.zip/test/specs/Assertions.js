describe('Working with Assertions', function(){

    it('Learning assertions with expect command', async () => {

        await browser.url('http://zero.webappsecurity.com/login.html')   
        
        // validate the current url in the browser
        await expect(browser).toHaveUrl("http://zero.webappsecurity.com/login.html")


        // validate partial url or url constaining a value
        await expect(browser).toHaveUrl(expect.stringContaining('login'))

        // calidate title of the page
        // await expect(browser).toHaveTitle('Zero - Log in')

        const title = await browser.getTitle()
        expect(title).toBe('Zero - Log in')
        
        // validate text
        await expect($('h3')).toHaveText('Log in to ZeroBank')
        // example - await expect($('#alert_content')).toHaveText('Foreign currency cash was successfully purchased.')
    
        // validate partial text
        await expect($('h3')).toHaveText(expect.stringContaining('Log in'))


        // validate value into the text field
        const loginBox = $('#user_login')
        await loginBox.setValue('username')

        await expect(loginBox).toHaveValue('username')

        // negation validation
        await expect(title).not.toBe('Error')


        // Validate if clickable/enabled/displayed
        const signinButton = await $('[name="submit"]')

        await expect(signinButton).toBeClickable()
        await expect(signinButton).toBeEnabled()
        await expect(signinButton).toBeDisplayed()
        await expect(signinButton).toBeExisting()



        await browser.pause(3000)

        
    })

    

})