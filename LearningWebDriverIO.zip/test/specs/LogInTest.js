describe("LogInTest", () => {
  it("tests LogInTest", async () => {
    
    await browser.url("https://the-internet.herokuapp.com/login")
    await browser.$("#username").setValue("tomsmith")
    await browser.$("#password").setValue("SuperSecretPassword!")
    await browser.$("aria/Login").click()
    
  });
});
