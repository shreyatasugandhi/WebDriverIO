describe('WebdriverIO Frame & Window Handling', () => {

    it('should switch to an iframe and validate text', async () => {
        await browser.url('http://the-internet.herokuapp.com/iframe')

        // Locate and switch to the iframe
        const iframe = await $('#mce_0_ifr')
        await browser.switchFrame(iframe)

        // Get text inside the iframe
        const iframeBody = await $('#tinymce')
        await expect(iframeBody).toHaveText(expect.stringContaining('Your content goes here.'))

        // Switch back to main window
        await browser.switchFrame(null)
    })


    it('should open a new tab and switch back', async () => {

        await browser.url('http://the-internet.herokuapp.com/windows');

        // Store the original window handle
        const originalWindow = await browser.getWindowHandle();

        // Click the link to open a new window
        const link = await $('=Click Here');
        await link.click();

        // Wait for the new window to open
        await browser.waitUntil(
            async () => (await browser.getWindowHandles()).length > 1,
            {
                timeout: 5000,
                timeoutMsg: 'Expected a new window to open'
            }
        );

        // Get all window handles
        const windowHandles = await browser.getWindowHandles();

        console.log('List of window handles -  ',windowHandles)


        // Find the new window handle
        const newWindowHandle = windowHandles.find(handle => handle !== originalWindow);
        await browser.switchToWindow(newWindowHandle);

        // Wait for the new window to load completely
        await browser.waitUntil(async () => (await browser.getTitle()) === 'New Window', {
            timeout: 5000,
            timeoutMsg: 'Expected title to be "New Window"',
        });

        // Validate the new window title
        await expect(browser).toHaveTitle('New Window');


        // Switch back to the original window
        await browser.switchToWindow(originalWindow);

        // Validate the original window title
        await expect(browser).toHaveTitle('The Internet');
    })

})
