module.exports = {

    url: 'https://the-internet.herokuapp.com/login',
    username: 'tomsmith',
    password: 'SuperSecretPassword!'
    
}