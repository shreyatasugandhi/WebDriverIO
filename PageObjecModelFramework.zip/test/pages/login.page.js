class loginPage {
    get username() {
        return $('#username')
    }
    get password() {
        return $('#password')
    }
    get loginButton() {
        return $('button[type="submit"]')
    }
    get messageBox() {
        return $('#flash')
    }

    async login(username, password) {
        await this.username.setValue(username)
        await this.password.setValue(password)
        await this.loginButton.click()
    }

    async checkLoginMessage(message) {
        await expect(this.messageBox).toHaveText(expect.stringContaining(message))
    }
}
module.exports = new loginPage();