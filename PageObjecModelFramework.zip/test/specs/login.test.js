const LoginPage = require('../pages/login.page')
const confdata = require('../config/conf')


describe('Log In Test cases', function() {
   it('Login Test with valid usernae and password', async () => {

        await browser.url(confdata.url)
        await browser.maximizeWindow()
        await LoginPage.login(confdata.username, confdata.password)
        await LoginPage.checkLoginMessage('You logged into a secure area!')

   })
})